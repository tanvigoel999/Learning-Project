const { request, response } = require("express");
const exp = require("express");
const { resolveTypeReferenceDirective } = require("typescript");
const productApp = exp.Router();
productApp.use(exp.json());
productApp.get("/get-products", async (request, response) => {
  //getProductCollection
  let productCollectionObject = request.app.get("productCollectionObject");
  let product = await productCollectionObject.find().toArray();
  response.send({ message: "Product", payload: product });
});

productApp.post("/create-products", async (request, response) => {
  let productCollectionObject = request.app.get("productCollectionObject");
  let productPut = request.body;
  console.log(productPut);
  let productDB = await productCollectionObject.findOne({
    product: productPut.product,
  });
  // console.log(productDB);
  if (productDB !== null) {
    response.send({ message: "Product is already exit" });
  } else {
    await productCollectionObject.insertOne(productPut);
    response.send({ message: "Product created" });
  }
});
productApp.post("/update-products", async (request, response) => {
  let productCollectionObject = request.app.get("productCollectionObject");
  let productUpdate = request.body;
  await productCollectionObject.updateOne(
    { product: productUpdate.product },
    { $set: { ...productUpdate } }
  );
  response.send({ message: "Product updated" });
});
productApp.delete("/remove-products/:id", async (request, response) => {
  let productCollectionObject = request.app.get("productCollectionObject");
  let removeProduct = request.body;
  console.log(removeProduct);
  await productCollectionObject.deleteOne(removeProduct);
  response.send({ message: "Product Deleted" });
});

productApp.get("/get-product/:product", async (request, response) => {
  let productCollectionObject = request.app.get("productCollectionObject");
  let ProductFromUrl = request.params.product;
  let productfind = await productCollectionObject.findOne({
    product: ProductFromUrl,
  });
  console.log(productfind);

  if (productfind === null) {
    response.send({ message: "Not existed" });
  } else {
    response.send({ message: "Product", payload: productfind });
  }
});
productApp.get("/get-productID/:id", async (request, response) => {
  let productCollectionObject = request.app.get("productCollectionObject");
  let ProductFromUrl = parseInt(request.params.id);
  console.log(ProductFromUrl);

  let productfind = await productCollectionObject.findOne({
    id: ProductFromUrl,
  });
  console.log(productfind);

  if (productfind === null) {
    response.send({ message: "Not existed" });
  } else {
    response.send({ message: "Product", payload: productfind });
  }
});

module.exports = productApp;
//get product by Id
//create product
//update product
//delete product by id
